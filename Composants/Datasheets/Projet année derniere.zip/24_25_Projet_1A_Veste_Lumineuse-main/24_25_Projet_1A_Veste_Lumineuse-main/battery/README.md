#Ce document est le readme pour la partie batterie de la veste lumineuse.

Elle est traitée par Clément Servaes et Léonard Navizet

##Explications des différents raisonnements et choix des composants:
Nous n'avons pas choisis nos composant actifs mais dimentioné nos composants passif.

Voici la bill of material qui est une liste des composants utilisés dans le projet :
![Bill of Material](Images/Bill_material.png)

Donc nous allons résumer le fonctiononement des composants utilisé et expliquer le choix des composants associé:
### 🟦 1. [STM32]
- **Référence :STM32G431KBTx**  
- **Fonction :Microcontroleur**  
- **Où il est utilisé :**

---

### 🟨 2. [Nom du composant]
- **Référence :**  
- **Fonction :**  
- **Où il est utilisé :**

---

### 🟥 3. [Nom du composant]
- **Référence :**  
- **Fonction :**  
- **Où il est utilisé :**

---
