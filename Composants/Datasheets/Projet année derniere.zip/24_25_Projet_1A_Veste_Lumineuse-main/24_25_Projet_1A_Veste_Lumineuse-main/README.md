# 24_25_Projet_1A_Veste_Lumineuse

* [Revue schéma](1-revue_schema.md)

* [Readme LED](LED/README.md)

* [Readme batterie](battery/README.md)
  
## Pense bete Git

```bash
git pull
# travail travail travail
git status
git add .
git commit -m "texte intelligent"
git push
```
