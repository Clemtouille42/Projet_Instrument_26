Lamyae Sdiri  
Diodio Diop  
Junior SIDIBE
